<?php include('_partials/top.php') ?>

<h1 class="page-header">Theme</h1>

<?php include('_partials/bottom.php') ?>
